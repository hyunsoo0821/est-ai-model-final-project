import googleapiclient.discovery
import time

# ⭐️ 이 부분은 반드시 본인의 API 키로 대체해야 합니다. ⭐️
API_KEY = "AIzaSyDj9LKuMdeLq5Uqfd0q3-8QDnV_lX-XsSQ" 

# ⭐️ 3단계 (영상 캡처본 분석)에서 받아온 최종 키워드 ⭐️
final_search_query = "웃긴 강아지 폭발 반응" 

# --------------------------------------------------------------------------------

def search_youtube_and_recommend(query, max_results=5, order='relevance'):
    """
    키워드(query)를 사용하여 YouTube 영상을 검색하고 추천 목록을 반환하는 함수
    
    max_results 매개변수에 의해 검색 결과가 최대 5개로 제한됩니다.
    """
    if not API_KEY or API_KEY == "YOUR_API_KEY":
        print("경고: API 키가 설정되지 않았거나 유효하지 않습니다. 검색을 건너뜁니다.")
        return []

    if not query:
        print("경고: 검색 쿼리가 비어있습니다. 키워드 추출 단계를 확인해 주세요.")
        return []
        
    # YouTube 클라이언트 객체 초기화
    try:
        youtube = googleapiclient.discovery.build(
            "youtube", 
            "v3", 
            developerKey=API_KEY
        )
    except Exception as e:
        print(f"[-] YouTube 클라이언트 초기화 오류: {e}")
        return []

    print(f"\n[+] 검색 시작: '{query}'를 기반으로 영상을 크롤링합니다. (최대 {max_results}개)")
    
    # ⭐️ maxResults를 함수 인수로 받은 max_results로 설정 (기본값 5) ⭐️
    request = youtube.search().list(
        q=query,             
        part="snippet",      
        type="video",        
        maxResults=max_results, 
        order=order          
    )
    
    # 403 오류에 대비하여 재시도 로직 추가
    MAX_RETRIES = 2
    for attempt in range(MAX_RETRIES):
        try:
            response = request.execute()
            
            videos = []
            for item in response.get("items", []):
                video_id = item['id']['videoId']
                video_data = {
                    'title': item['snippet']['title'],
                    'channel_title': item['snippet']['channelTitle'],
                    'video_url': f"https://www.youtube.com/watch?v={video_id}"
                }
                videos.append(video_data)
                
            return videos # 성공적으로 데이터를 받으면 리턴 (최대 5개)
            
        except Exception as e:
            error_message = str(e)
            print(f"[-] YouTube API 호출 오류 발생 (시도 {attempt + 1}/{MAX_RETRIES}): {error_message}")
            
            if attempt < MAX_RETRIES - 1:
                print("    잠시 후 재시도합니다 (3초 대기)...")
                time.sleep(3)
            else:
                print("[-] 최대 재시도 횟수를 초과하여 검색에 실패했습니다.")
                return []
            
    return []

# --------------------------------------------------------------------------------

def present_recommendations(recommended_videos):
    """
    추천 영상 목록을 보기 좋게 출력하는 함수
    """
    if not recommended_videos:
        print("[-] 키워드에 해당하는 추천 영상을 찾을 수 없습니다.")
        return

    # ⭐️ 출력되는 영상의 개수는 이 리스트의 길이에 따라 결정됩니다. ⭐️
    print("\n=============================================")
    print(f"🎉 추천 영상 목록 (키워드: {final_search_query}, 총 {len(recommended_videos)}개)")
    print("=============================================")
    for i, video in enumerate(recommended_videos):
        print(f"[{i+1}] {video['title']}")
        print(f"    - 채널: {video['channel_title']}")
        print(f"    - 링크: {video['video_url']}")
    print("=============================================")


# 🚀 함수 실행
# max_results=5를 명시적으로 지정하여 최대 5개의 영상만 요청합니다.
RECOMMENDATION_LIMIT = 5 
recommended_videos = search_youtube_and_recommend(
    query=final_search_query, 
    max_results=RECOMMENDATION_LIMIT 
)

# 🖥️ 결과 제시
present_recommendations(recommended_videos)